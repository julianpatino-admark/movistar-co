<div class="card-offer destacado">

	<div class="card-offer_wrapper">

		<div class="card-offer_header header-movil">
			<p class="title">&nbsp;</p>
			<h3 class="main-title" style="font-size: 40px; margin: 5px 0 0px 0;">ILIMIDATOS</h3>
			<h6 class="subtitle">DATOS ILIMITADOS</h6>
		</div>

		<div class="card-offer_body">

			<div class="body-title">
				&nbsp;
			</div>

			<div class="card-offer_price">
				<p class="card-offer_price-number">
					121.990
				</p>
				<p class="card-offer_price-text">
					&nbsp;
				</p>
			</div>


			<div class="card-offer_cta">
				<a
					class="btn-flex btn-accent-b"
					data-c2c="offer-one"
					data-toggle="modal"
					data-modal-title="ILIMIDATOS"
					data-target="#modal-velocidades"
					data-tag-page="/modal/offer-1-mobile/c2c"
					data-show-element="#modal-header-phone"
				>
					LO QUIERO
				</a>
			</div>

		</div>

		<div class="card-offer_footer">
			<div class="package-item">
				<div>
					@include("vendor.partials.components.icons.menu.movil")
				</div>
				<div>
					<h4>Minutos ilimitados</h4>
					<p>USA, CANADA, PUERTO RICO</p>
				</div>
			</div>

			<div class="package-included">
				<p class="budget">Ahorra $41.900 con:</p>
				<div>
					<img width="29" height="29" src="{{ asset('img/common/logo-disney+.webp') }}" alt="Logo de App para Disney+">
					<img width="29" height="29" src="{{ asset('img/common/logo-star+.webp') }}" alt="Logo de App para Star+">
				</div>
				<div>Incluidos en tu plan</div>
			</div>
		</div>
	</div>
</div>
