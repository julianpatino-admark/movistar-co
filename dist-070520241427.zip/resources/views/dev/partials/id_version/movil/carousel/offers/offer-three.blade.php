<div class="card-offer">

	<div class="card-offer_wrapper">

		<div class="card-offer_header header-movil">
			<p class="title">PRIMER MES GRATIS</p>
			<h3 class="main-title mb-0">90 GB</h3>
			<h6 class="subtitle">120 GB si tienes internet hogar movistar</h6>
		</div>

		<div class="card-offer_body">

			<div class="body-title">
				<div class="body-title_container">
					<div class="discount">50%dcto</div>
					<div class="months">meses 2 y 3</div>
				</div>
			</div>

			<div class="card-offer_price">
				<p class="card-offer_price-number">
					$27.495
				</p>
				<p class="card-offer_price-text">
					Normal $54.990
				</p>
			</div>


			<div class="card-offer_cta">
				<a
					class="btn-flex btn-accent"
					data-c2c="MOVIL 80 Gb"
					data-toggle="modal"
					data-modal-title="80 Gb"
					data-target="#modal-velocidades"
					data-tag-page="/modal/offer-3-mobile/c2c"
					data-show-element="#modal-header-phone"
				>
					LO QUIERO
				</a>
			</div>

		</div>

		<div class="card-offer_footer">
			<div class="package-item">
				<div>
					@include("vendor.partials.components.icons.menu.movil")
				</div>
				<div>
					<h4>Minutos ilimitados</h4>
					<p>USA, CANADA, PUERTO RICO</p>
				</div>
			</div>

			<div class="package-item">
				<div>
					@include("vendor.partials.components.icons.cards.movistar")
				</div>
				<div>
					<h4>Elige hasta 7 apps</h4>
					<p>de Redes Sociales +</p>
				</div>
			</div>
		</div>
	</div>
</div>
