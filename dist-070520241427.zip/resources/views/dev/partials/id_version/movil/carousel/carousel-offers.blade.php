<div class="carousel-wrapper">
	<div class="splide container position-relative" id="offert-carrousel">
		<h2 class="title-section text-center mb-2">Conoce más de los Planes Movistar Pospago</h2>
		<h3 class="subtitle-section text-center mb-3">Escoge un plan para tus necesidades</h3>

		<div class="splide__track">

			<div class="splide__list">
				<div class="splide__slide">
					<!-- card--->
					@include('dev.partials.id_version.movil.carousel.offers.offer-one')
				</div>
				<div class="splide__slide">
					<!-- card --->
					@include('dev.partials.id_version.movil.carousel.offers.offer-two')
				</div>
				<div class="splide__slide">
					<!-- card --->
					@include('dev.partials.id_version.movil.carousel.offers.offer-three')
				</div>
				<div class="splide__slide">
					<!-- card --->
					@include('dev.partials.id_version.movil.carousel.offers.offer-six')
				</div>
			</div>
		</div>

		<div class="splide__arrows">
			<button class="splide__arrow splide__arrow--prev">
				@include('dev.partials.components.icons.buttons.arrow-left')
			</button>
			<button class="splide__arrow splide__arrow--next">
				@include('dev.partials.components.icons.buttons.arrow-right')
			</button>
		</div>
		<ul class="splide__pagination"></ul>

		<p class="terminos-condiciones">
			*Aplican términos y condiciones. Basado en el análisis realizado por Ookla de los datos de SpeedTest Intelligence® para el segundo y tercer trimestre de 2022. Las marcas registradas de Ookla se usan bajo licencia y se reimprimen con permiso.
		</p>
	</div>
</div>






