<div class="main-banner sld-2">
    <div class="container">
        <h1 class="main-banner_title">Planes de internet, telefonía fija y televisión</h1>
        <x-responsive-image
            class="oferta"
            width="200"
            height="113"
            alt="Planes de ilimidatos con combo plus incluido"
            name="oferta"
            breakpoints="lg,md,sm"
            sizes="304;173,200;113,200;113"
            path="img/movil/main-banner"
        ></x-responsive-image>
        <x-responsive-image
            class="beneficios"
            width="280"
            height="44"
            alt="si activas un plan tienes: 100 megas extra; 50% mas de datos; beneficios exclusivos"
            name="beneficios"
            breakpoints="lg,md,sm"
            sizes="426;67,280;44,280;44"
            path="img/movil/main-banner"
        ></x-responsive-image>

        <div class="main-banner_cta">
            <button
                data-c2c="OFERTA MOVIL"
                data-toggle="modal"
                data-target="#modal-c2c"
                data-test-id= "calcula-banner-btn"
                data-tag-page="/modal/oferta-main-banner/c2c"
                class="btn-flex btn-accent-b shadow-lg"
            >
                Contratar Fibra
            </button>
        </div>
        <div class="main-banner_tyc d-none d-flex-lg">* Aplican términos y condiciones.</div>
    </div>
</div>
