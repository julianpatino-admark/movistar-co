<div class="card-offer destacado">

	<div class="card-offer_title">
		NUESTRA MEJOR OFERTA
	</div>

	<div class="card-offer_wrapper">

		<div class="card-offer_header">
			<div class="label">700MB si aún no eres cliente Pospago</div>
			<h3 class="main-title">800 Megas</h3>
		</div>
		<div class="card-offer_body-discount">
			<img width="13" height="13" src="{{ asset('img/common/icon-descuento.webp') }}" alt="Icono de descuento" />
			<p class="months">20% dto x 12 meses</p>
		</div>
		<div class="card-offer_body">
			<p class="card-offer_price-number">
				$135.992
			</p>
			<p class="card-offer_price-text">
				Normal: $169.990
			</p>
		</div>

		<div class="card-offer_footer">
			<div class="card-offer_cta">
				<button
					class="btn-flex btn-carousel"
					data-c2c="INTERNET 800 MB COMBO PLUS"
					data-toggle="modal"
					data-modal-title="800 Mb"
					data-target="#modal-velocidades"
					data-tag-page="/modal/offer-3-fibra/c2c"
					data-show-element="#modal-header-phone"
				>
					LO QUIERO
				</button>
			</div>
			<div class="package-included">
				<p>Incluidos en tu plan</p>
				<img width="107" height="44" src="{{ asset('img/common/logo-combo-plus.webp') }}" alt="Logo de Disney+ y Star+">
			</div>
		</div>
	</div>
</div>

