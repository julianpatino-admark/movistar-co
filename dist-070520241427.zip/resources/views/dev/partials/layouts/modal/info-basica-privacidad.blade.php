<div id="modal-info-basica-privacidad" class="modal modal-brand modal-text fade" tabindex="-1" role="dialog"
     data-show="false">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal_title">Información Básica Sobre Protección de Datos</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
			</div>
			<div class="modal-body">
				<div class="modal_content">
					@include('dev.partials.layouts.texts.info-basica-privacidad')
				</div>
			</div>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>