<div id="modal-manual" class="modal modal-brand modal-text fade" tabindex="-1" role="dialog" data-show="false">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close"  data-dismiss="modal" aria-label="Close">&times;</button>
				<h5 class="modal_title"></h5>
			</div>
			<div class="modal-body">
				<div class="modal_content modal-scrollable preserve-text">
					@include('dev.partials.layouts.texts.tratamiento-datos')
				</div>
			</div>
		</div>
	</div>
</div>