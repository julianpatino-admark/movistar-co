<h4>POLÍTICAS DE TRATAMIENTO Y TRANSFERENCIA DE DATOS PERSONALES</h4>
<h5>1. Principios generales y postulados</h5>
La empresa <b>Konecta Digital Mk Agency</b>, identificada con Nit. 901.127.989-3, como responsable del
tratamiento de datos personales, y dando cumplimiento a las disposiciones contenidas en la ley 1581 de 2012, el
Capítulo 25 del Decreto reglamentario 1074 de 2015 y las normas que la modifiquen, adicionen o complementen, en
adelante “LA EMPRESA”, garantiza la protección de derechos fundamentales como el Habeas Data, la privacidad, la
intimidad, el buen nombre, y la imagen de las personas; con tal propósito todas las actuaciones se regirán por
principios de buena fe, legalidad, autodeterminación informática, libertad y transparencia.

Quien, en ejercicio de cualquier actividad, incluyendo las financieras, comerciales y laborales, sean estas
permanentes u ocasionales, pueda suministrar cualquier tipo de información o dato personal a LA EMPRESA como
responsable del tratamiento, podrá conocerla, actualizarla y rectificarla.

<h5>2. Marco legal</h5>
Estas políticas se desarrollan y aplican teniendo en cuenta los artículos 15 y 20 de la Constitución Política de
Colombia, la ley 1581 de 2012, el Capítulo 25 del Decreto reglamentario 1074 de 2015, doctrinas y circulares de la
Superintendencia de Industria y Comercio y demás normas aplicables.

<h5>3. Definiciones </h5>
De conformidad con la legislación vigente sobre la materia, se establecen las siguientes definiciones, las cuales
serán aplicadas e implementadas acogiendo los criterios de interpretación que garanticen una aplicación sistemática
e integral, y en consonancia con los avances tecnológicos, la neutralidad tecnológica; y los demás principios y
postulados que rigen los derechos fundamentales que circundan, orbitan y rodean el derecho de habeas data y la
protección de datos personales.

<b>3.1. Autorización</b>: Consentimiento previo, expreso e informado del titular para llevar a cabo el tratamiento de
datos personales.

<b>3.2. Aviso de Privacidad</b>: Comunicación verbal o escrita generada por el responsable, dirigida al titular para el
tratamiento de sus datos personales, mediante la cual se le informa acerca de la existencia de las Políticas de
Tratamiento de la información que le serán aplicables, la forma de acceder a las mismas y las finalidades del
tratamiento que se pretende dar a los datos personales.

<b>3.3. Base de datos</b>: Conjunto organizado de datos personales que sea objeto de tratamiento.

<b>3.4. Dato personal</b>: Cualquier información vinculada o que pueda asociarse a una o varias personas naturales
determinadas o determinables.

<b>3.5. Encargado del tratamiento</b>: Persona natural o jurídica, pública o privada, que por sí misma o en asocio con
otros, realice el tratamiento de datos personales por cuenta del responsable del tratamiento.

<b>3.6. Responsable del tratamiento</b>: Persona natural o jurídica, pública o privada que por sí misma o en asocio con
otros, decida sobre la base de datos y/o el tratamiento de los datos

<b>3.7. Sistema Biométrico</b>: Es una tecnología de seguridad que se basa en el reconocimiento de las
características físicas e intransferibles de las personas. Es decir, es un método automatizado por medio del cual se puede de
manera precisa, reconocer a un individuo con base en sus características físicas o de comportamiento.

<b>3.8. Sistema de Video Vigilancia</b>: Los datos tratados mediante sistemas de Video Vigilancia serán preservados
cumpliendo con todas las disposiciones legales que garanticen la privacidad de estos. La finalidad del sistema
de video vigilancia consiste en resguardar la seguridad de los bienes de la empresa y sus empleados; sin
perjuicio de lo anterior, la compañía podrá utilizar la información contenida en las cámaras de video
vigilancia, como elemento probatorio con fines disciplinarios.

<b>3.9. Titular</b>: Persona natural cuyos datos personales sean objeto de tratamiento.

<b>3.10. Tratamiento</b>: Cualquier operación o conjunto de operaciones sobre datos personales, tales como recolección, almacenamiento, uso, circulación o supresión.

<h5>4. Principios específicos</h5>
LA EMPRESA aplicará los siguientes principios específicos que se establecen a continuación, los cuales constituyen
las reglas a seguir en la recolección, manejo, uso, tratamiento, almacenamiento e intercambio de datos
personales:

<b>a. Principio de legalidad</b>: En el uso, captura, recolección y tratamiento de datos personales, se dará
aplicación a
las disposiciones vigentes y aplicables que rigen el tratamiento de datos personales y demás derechos fundamentales
conexos.

<b>b. Principio de Libertad</b>: El uso, captura, recolección y tratamiento de datos personales sólo puede
llevarse a cabo con el consentimiento previo, expreso e informado del Titular. Los datos personales no podrán ser
obtenidos o divulgados sin previa autorización, o en ausencia de mandato legal, estatutario, o judicial que releve
el consentimiento.

<b>c. Principio de finalidad</b>: El uso, captura, recolección y tratamiento de datos personales a los
que tenga acceso y sean acopiados y recogidos por LA EMPRESA o sus proveedores estarán subordinados y atenderán una finalidad legítima, la cual debe serle informada al respectivo titular de los datos personales.
TLMARK SPAIN, S.L. SUCURSAL COLOMBIA ZO FNCA PERMANENTE ESPECIAL

<b>d. Principio de veracidad o calidad</b>: La información sujeta a uso, captura, recolección y tratamiento de datos
personales debe ser veraz, completa, exacta, actualizada,
comprobable y comprensible, Se prohíbe el Tratamiento de datos parciales, incompletos, fraccionados o que induzcan a
error.

<b>e. Principio de transparencia</b>: En el uso, captura, recolección y tratamiento de datos personales debe
garantizarse el derecho del Titular a obtener de la EMPRESA, en cualquier momento y sin restricciones, información
acerca de la existencia de cualquier tipo de información o dato personal que sea de su interés directo o
titularidad.

<b>f. Principio de acceso y circulación restringida</b>: Los datos personales, salvo la información pública,
no podrán estar disponibles en internet u otros medios de divulgación o comunicación masiva, salvo que el acceso sea
técnicamente controlable para brindar un conocimiento restringido solo a los Titulares o terceros autorizados. Para
estos propósitos la obligación de LA EMPRESA mediante su página web será la misma.

<b>g. Principio de seguridad</b>: Los datos personales e información usada, capturada, recolectada y sujeta a
tratamiento por LA EMPRESA, será objeto de
protección en la medida en que los recursos técnicos y estándares mínimos así lo permitan, a través de la adopción
de medidas tecnológicas de protección, protocolos, y todo tipo de medidas administrativas que sean necesarias para
otorgar seguridad a los registros y repositorios electrónicos evitando su adulteración, modificación, pérdida,
consulta, y en general en contra de cualquier uso o acceso no autorizado.

<b>h. Principio de confidencialidad</b>: Todas y
cada una de las personas que administren, manejen, actualicen o tengan acceso a datos personales que se encuentren
en Bases de Datos, deberán conservar la reserva de la información a la que tengan acceso, incluso una vez termine su
vinculación laboral o contractual con la Empresa, de acuerdo con los parámetros de la ley aplicable

<h5>5. Dato sensible</h5>
Se entiende por datos sensibles aquellos que afectan la intimidad del titular o cuyo uso indebido puede generar
discriminación, tales como aquellos que revelen el origen racial o étnico, la orientación política, las convicciones
religiosas o filosóficas, la pertenencia a sindicatos, organizaciones sociales, de derechos y garantías de partidos
políticos de oposición así como los datos relativos a la salud, a la vida sexual y los datos biométricos, entre
otros, la captura de imagen fija o en movimiento, huellas digitales, fotografías, iris, reconocimiento de voz,
facial o de palma de mano, etc.

<b>5.1. Tratamiento de datos sensibles:</b>

Se podrá hacer uso y tratamiento de los datos catalogados como sensibles cuando:

a. El Titular haya dado su autorización explícita a
dicho tratamiento, salvo en los casos que por ley no sea requerido el otorgamiento de dicha autorización.
b. El tratamiento sea necesario para salvaguardar el interés vital del titular y este se encuentre física o
jurídicamente
incapacitado. En estos eventos, los representantes legales deberán otorgar su autorización.
c. El tratamiento sea efectuado en el curso de las actividades legítimas y con las debidas garantías por parte de
una fundación, ONG,
asociación o cualquier otro organismo sin ánimo de lucro, cuya finalidad sea política, filosófica, religiosa o
sindical, siempre que se refieran exclusivamente a sus miembros o a las personas que mantengan contactos regulares
por razón de su finalidad. En estos eventos, los datos no se podrán suministrar a terceros sin la autorización del
titular.
d. El tratamiento se refiera a datos que sean necesarios para el reconocimiento, ejercicio o defensa de un
derecho de proceso judicial
e. El tratamiento tenga una finalidad histórica, estadística o científica. En este
evento deberán adoptarse las medidas conducentes a la supresión de identidad de los Titulares

<b>5.2. Autorización del titular</b>

Sin perjuicio de las excepciones previstas en la ley, en el tratamiento de datos personales sensibles LA EMPRESA
requerirá la autorización previa, libre, expresa e informada del titular, la cual deberá ser obtenida por cualquier
medio que pueda ser objetivo de consulta y verificación posterior.

<h5>6. Derechos de los niños, niñas y adolescentes.</h5>

En el tratamiento se asegurará el respeto a los derechos prevalentes de los menor
Queda proscrito el Tratamiento de datos personales de menores, salvo aquellos datos que sean de naturaleza
pública

<h5>7. Deberes de la EMPRESA como responsable del Tratamiento de los Datos Personales</h5>
La empresa, cuando actúe como responsable del Tratamiento de datos personales, cumplirá con los siguientes
deberes:
a. Garantizar al Titular, en todo tiempo, el pleno y efectivo ejercicio del derecho de hábeas data.
b. Solicitar y conservar, copia de la respectiva autorización otorgada por el titular
c. Informar debidamente al titular sobre la finalidad de la recolección y los derechos que le asisten por virtud de
la autorización otorgada
d. Conservar la información bajo las condiciones de seguridad necesarias para impedir su adulteración, pérdida,
consulta, uso o acceso no autorizado o fraudulento.
e. Garantizar que la información que se suministre al encargado del tratamiento sea veraz, completa, exacta,
actualizada, comprobable y comprensible.
f. Actualizar la información, comunicando de forma oportuna al encargado
del tratamiento, todas las novedades respecto de los datos que previamente le haya suministrado y adoptar las demás
medidas necesarias para que la información suministrada a este se mantenga actualizada.
g. Rectificar la información cuando sea incorrecta y comunicar lo pertinente al encargado del tratamiento.
h. Suministrar al encargado del Tratamiento, según el caso, únicamente datos cuyo tratamiento esté previamente
autorizado por la ley aplicable.
i. Exigir al Encargado del Tratamiento en todo momento, el respeto a las condiciones de seguridad y privacidad de la
información del Titular.
j. Tramitar las consultas y reclamos formulados.
k. Informar al Encargado del Tratamiento cuando determinada información se encuentre en discusión por parte del
Titular, una vez se haya presentado la
reclamación y no haya finalizado el trámite respectivo.
l. Informar a solicitud del Titular sobre el uso dado a sus datos.
m. Informar a la autoridad de protección de datos cuando se presenten violaciones a los códigos de seguridad
y existan riesgos en la administración de la información de los Titulares.
n. Implementar el sistema de Video Vigilancia solo cuando sea necesario para el cumplimiento de la finalidad
propuesta, respetando la dignidad y demás
derechos fundamentales de las personas.
o. limitar la recolección de imágenes a las estrictamente necesarias para
cumplir el fin específico previamente concebido.

<h5>8. Registro Nacional de bases de datos.</h5>
La empresa, se reserva en los eventos contemplados en la ley y sus estatutos y reglamentos internos, la facultad de
mantener y catalogar determinada información que repose en sus bases o bancos de datos, como confidencialidad de
acuerdo con las normas vigentes, sus estatutos y reglamentos, todo lo anterior y en consonancia con el derecho de la
autonomía Empresarial
La empresa, procederá de acuerdo con la normatividad vigente y la reglamentación que para tal fin expida el Gobierno
Nacional, a realizar el registro y actualización de sus bases de datos, ante El Registro Nacional de Bases de Datos
(RNDB) que será LEMARK SPAIN, S.L. SUCURSAL COLOMBIA ZO FNCA PERMANENTE ESPECIAL administrado por la
Superintendencia de Industria y Comercio. El RNBD, es el directorio público de las bases de datos sujetas al
Tratamiento que operan en el país; y que será de libre consulta para los ciudadanos, de acuerdo con la normatividad
que para tal efecto expida el Gobierno Nacional.


<h5>9. Autorizaciones y consentimiento.</h5>
La recolección, almacenamiento, uso, o supresión de datos personales por parte de La empresa, requiere del
consentimiento libre, previo, expreso e informado del titular de estos.

<b>9.1 Medio y manifestaciones para otorgar la autorización.</b>
La autorización puede constar en un documento físico, electrónico, mensaje de datos, internet, Sitios Web, o en
cualquier otro formato que permita garantizar su posterior consulta, o mediante un mecanismo técnico e incluso
mediante autorización verbal grabada o cualquier medio tecnológico idóneo, que permita manifestar u obtener el
consentimiento vía clic o doble clic, mediante el cual se pueda concluir de manera inequívoca, que de no haberse
surtido una conducta del titular, los datos nunca hubieren sido capturados y almacenados en la base de datos. La
autorización será generada por LA EMPRESA y será puesta a disposición del titular con antelación y de manera
previa al tratamiento de sus datos personales.

<b>Prueba de la autorización:</b>
LA EMPRESA utilizará los mecanismos con los que cuenta actualmente, e implementará y adoptará las acciones
tendientes y necesarias para mantener registros o mecanismos técnicos o tecnológicos idóneos de cuándo y cómo
obtuvo autorización por parte de los titulares de datos personales para el tratamiento de estos. Para dar
cumplimiento a lo anterior, se podrán establecer archivos físicos o repositorios electrónicos realizados de
manera directa o a través de terceros contratados para tal fin.

<b>9.3. Casos en que no se requiere la autorización:</b>

La autorización del Titular no será necesaria cuando se trate de:

a. Información requerida por una entidad pública o administrativa en ejercicio de sus funciones legales o por orden judicial.
b. Datos de naturaleza pública.
c. Casos de urgencia médica o sanitaria.
d. Tratamiento de información autorizado por la ley para fines históricos, estadísticos o científicos.
e. Datos relacionados con el Registro Civil de las personas.

<h5>10. Aviso de privacidad:</h5>
El Aviso de la Privacidad es la comunicación verbal o documento físico, electrónico o en cualquier otro formato
conocido o por conocer, que es puesto a disposición del Titular para el tratamiento de sus datos personales. A
través de este documento se informa al Titular la información relativa a la existencia de las políticas de
tratamiento de información que le serán aplicables, la forma de acceder a las mismas y a las características del
tratamiento que se pretende dar a los datos personales.

<b>10.1 Alcance y Contenido del Aviso de Privacidad</b>

El aviso de Privacidad, como mínimo deberá tener la siguiente información:

a. La identidad, domicilio y datos de contacto del responsable del Tratamiento.
b. El tipo de tratamiento al cual serán sometidos los datos y la finalidad de este.
c. Los derechos que le asisten al titular.
d. Los mecanismos generales dispuestos por el responsable para que el titular conozca la política de tratamiento de
la información y los cambios sustanciales que se produzcan en ella. En todos los casos, debe informar al titular
cómo acceder o consultar la política del tratamiento de información.


<h5>11. Prerrogativas y demás derechos de los titulares de la información </h5>
En atención y en consonancia con lo dispuesto en la normatividad vigente y aplicable en materia de protección de
datos personales, el titular de los datos personales tiene los siguientes derechos:

a. Acceder, conocer, rectificar y actualizar sus datos personales frente a LA EMPRESA, en su condición de
responsable del tratamiento.
b. Por cualquier medio válido, solicitar prueba de la autorización otorgada a LA EMPRESA, en su condición de
responsable del Tratamiento.
c. A recibir información por parte de LA EMPRESA previa solicitud, respecto del uso que le ha dado a sus datos
personales.
d. Acudir ante las autoridades legalmente constituidas, en especial ante la Superintendencia de Industria y
Comercio, y presentar quejas por infracciones a lo dispuesto en la normatividad vigente en las normas
aplicables, previo tramite de consulta o requerimiento ante el responsable del Tratamiento.
e. Modificar y revocar la autorización y/o solicitar la supresión del dato cuando en el Tratamiento no se respeten
los principios, derechos y garantías constitucionales y legales vigentes.
f.Tener conocimiento y acceder en forma gratuita a sus datos personales que hayan sido objeto de Tratamiento.

<h5>12.Deberes de LA EMPRESA en relación con el tratamiento de los datos personales. </h5>
LA EMPRESA tendrá presente, en todo momento, que los datos personales son propiedad de las personas a las que se
refieren y que sólo ellas pueden decidir sobre los mismos. En este sentido, hará uso de ellos sólo para aquellas
finalidades para las que se encuentra facultado debidamente, y respetando en todo caso la normatividad vigente
sobre protección de datos personales.

<h5>13. Garantías del Derecho de Acceso.</h5>
LA EMPRESA garantizará a los titulares el derecho de acceso a su información personal cuando, previa
acreditación de la identidad del titular o legitimidad e identidad de su representante, así lo soliciten. Se
dispondrán de medios ágiles como los medios electrónicos para este fin. El acceso a los datos personales por
parte de los titulares será gratuito, sin perjuicio de las limitaciones a las que se refiere el artículo
2.2.2.25.4.2 del Decreto reglamentario 1074 de 2015.

<h5>14. Consultas.</h5>
Los titulares, o sus causahabientes podrán consultar la información personal del Titular que repose en cualquier
base de datos. En consecuencia, LA EMPRESA garantizará el derecho de consulta, suministrando a los titulares,
toda la información contenida en el registro individual o que esté vinculada con la identificación del titular.
Con respecto a la atención de solicitudes de consulta de datos personales LA EMPRESA garantiza:
a. Habilitar medios de comunicación electrónica u otros que considere pertinentes.
b. Establecer formularios, sistemas y otros métodos simplificados, mismos que deben ser informados en el aviso de
privacidad.
c. Utilizar los servicios de atención al cliente o de reclamaciones que tiene en operación.

En cualquier caso, independientemente del mecanismo implementado para la atención de solicitudes de consulta,
las mismas serán atendidas en un término máximo de diez (10) días hábiles contados a partir de la fecha su
recibo. Cuando no fuere posible atender la consulta dentro de dicho término, se informará al interesado antes
del vencimiento de los 10 días expresando los motivos de la demora y señalando la fecha en que se atenderá su
consulta, la cual en ningún caso podrá superar los cinco (5) días hábiles siguientes al vencimiento del primer
plazo.

<h5>15. Reclamos.</h5>
El Titular o sus causahabientes que consideren que la información contenida en una base de datos deber ser
objeto de corrección, actualización o supresión, o cuando advierten el presunto incumplimiento de cualquiera de
los deberes contenidos en la Ley, podrán presentar un reclamo ante el Responsable del Tratamiento, canalizándola
y remitiéndola a través de la dependencia designada y cuyos datos de contacto se concretan más adelante en el
numeral 23 del presente documento y que ejercerá la función de protección de datos personales al interior de LA
EMPRESA.

El reclamo lo podrá presentar el Titular, teniendo en cuenta la información señalada en el artículo 15 de la ley
1581 de 2012 y en el Capítulo 25 del Decreto reglamentario 1074 de 2015 y demás normas que los modifiquen o
adicionen.

<h5>16. Implementación de procedimientos para garantizar el derecho a presentar reclamos. </h5>
En cualquier momento y de manera gratuita el titular o su representante podrán solicitar al personal de LA
EMPRESA, la rectificación, actualización o supresión de sus datos personales, previa acreditación de su
identidad. Los Derechos de rectificación, actualización o supresión únicamente se podrán ejercer por:

a. El titular o sus causahabientes, previa acreditación de su identidad, o a través de instrumentos electrónicos
que le permitan identificarse.
b.Su representante, previa acreditación de la representación.

Cuando la solicitud sea formulada por persona distinta del titular, deberá acreditarse en debida forma la
personería o mandato para actuar; y en caso de no acreditar tal calidad, la solicitud se tendrá por no
presentada.

La solicitud de rectificación, actualización o supresión debe ser presentada a través de los medios habilitados
por LA EMPRESA señalados en el aviso de privacidad y contener, como mínimo, la siguiente información:

a. El nombre y domicilio del titular o cualquier otro medio para recibir la respuesta.
b. Los documentos que acrediten la identidad o la personalidad de su representante.
c. La descripción clara y precisa de los datos personales respecto de los cuales el titular busca ejercer alguno de los derechos.
d. En caso dado otros elementos o documentos que faciliten la localización de los datos personales.

<h5>17. Rectificación y actualización de datos. </h5>
LA EMPRESA tiene la obligación de rectificar y actualizar a solicitud del titular, la información de éste que
resulte ser incompleta o inexacta, de conformidad con el procedimiento y los términos arriba señalados. Al respecto se tendrá en cuenta lo siguiente:
En las solicitudes de rectificación y actualización de datos personales el titular debe indicar las correcciones
a realizar y aportar la documentación que avale su petición./p>
LA EMPRESA tiene plena libertad de habilitar mecanismos que le faciliten el ejercicio de este derecho, siempre y
cuando éstos beneficien al titular. En consecuencia, se podrán habilitar medios electrónicos u otros que consideren pertinentes.
LA EMPRESA podrá establecer formularios, sistemas y otros métodos simplificados, mismos que deben ser informados
en el aviso de privacidad y que se pondrán a disposición de los interesados en la página web.

<h5>18. Supresión de datos.</h5>
El titular tiene el derecho, en todo momento, a solicitar a LA EMPRESA la supresión (eliminación) de sus datos
personales cuando:

a. Considere que los mismos no están siendo tratados conforme a los principios, deberes y obligaciones previstas en normatividad vigente.
b. Hayan dejado de ser necesarios o pertinentes para la finalidad para la cual fueron recabados.
c. Se haya superado el período necesario para el cumplimiento de los fines para los que fueron recabados.

Esta supresión implica la eliminación total o parcial de la información personal de acuerdo con lo solicitado
por el titular en los registros, archivos, bases de datos o tratamientos realizados por LA EMPRESA. Es
importante tener en cuenta que el derecho de cancelación no es absoluto y el responsable puede negar el
ejercicio de este cuando:

a.El titular tenga un deber legal o contractual de permanecer en la base de datos.
b.La eliminación de datos obstaculice actuaciones judiciales o administrativas vinculadas a obligaciones fiscales, la investigación y persecución de delitos o la actualización de sanciones administrativas.
c.Los datos sean necesarios para proteger los intereses jurídicamente del titular; para realizar una acción en función del interés público, o para cumplir con una obligación legamente adquirida por el titular.

<h5>19. Revocatoria de la autorización.</h5>
Los titulares de los datos personales pueden revocar el consentimiento al tratamiento de sus datos personales en
cualquier momento, siempre y cuando no lo impida una disposición legal o contractual. Pare ello, LA EMPRESA
establecerá mecanismos sencillos y gratuitos que permitan al titular revocar su consentimiento, al menos por el
mismo medio por el que lo otorgó.

Se deberá tener en cuenta que existen dos modalidades en las que la revocación del consentimiento puede darse.
La primera puede ser sobre la totalidad de las finalidades consentidas, esto es, que LA EMPRESA deba dejar de
tratar por completo los datos del titular; la segunda, puede ocurrir sobre tipos de tratamiento determinados,
como por ejemplo para fines publicitarios o de estudios de mercado. Con la segunda modalidad, esto es, la
revocación parcial del consentimiento, se mantienen a salvo otros fines del tratamiento que el responsable, de
conformidad con la autorización otorgada puede llevar a cabo y con los que el titular está de acuerdo.

<h5>20. Seguridad de la información y medidas de seguridad.</h5>
En desarrollo del principio de seguridad establecido en la normatividad vigente, LA EMPRESA adoptará las medidas
técnicas, humanas y administrativas que sean necesarias para otorgar seguridad a los registros evitando su
adulteración, pérdida, consulta, uso o acceso no autorizado o fraudulento.

<h5>21. Utilización y finalidad del tratamiento de datos personales</h5>
El tratamiento de los datos personales que recolecte LA EMPRESA tendrá las siguientes finalidades:

Administrativas: Atención de requerimientos de autoridades; mantenimiento por sí mismo o a través de un tercero
de las bases de datos.

Laborales: manejo de nómina, procesos de admisión y selección de personal de LA EMPRESA o de terceros;
vinculación al sistema de seguridad social; y cualquier otro uso que se considere necesario para dar
cumplimiento a la ley y a las obligaciones de carácter laboral.

Comerciales, contractuales y financieros: procesos de admisión, selección y vinculación de contratistas,
proveedores y clientes de LA EMPRESA; lograr una eficiente comunicación con las partes intervinientes en los
contratos que se suscriban en desarrollo de los proyectos de LA EMPRESA; validación de la vinculación al sistema
de seguridad social; manejo y envío de comunicaciones con fines informativos o de mercadeo; llamadas;
información sobre la celebración de alianzas; y con fines estadísticos.

<h5>22. Transferencia internacional de datos personales e información personal por parte de LA EMPRESA.</h5>
Dependiendo de la naturaleza de las relaciones permanentes u ocasionales que cualquier persona titular de datos
personales pueda tener para con LA EMPRESA, la totalidad de su información puede ser transferida al exterior,
sujeto a los requerimientos legales aplicables, con la aceptación de la presente política, autoriza expresamente
para transferir información Personal. La información será transferida, para todas las relaciones que puedan
establecerse con LA EMPRESA.
Sin perjuicio de la obligación de observar y mantener la confidencialidad de la información, LA EMPRESA tomará
las medidas necesarias para que esos terceros conozcan y se comprometan a observar esta Política, bajo el
entendido de que la información personal que reciban únicamente podrá ser utilizada para asuntos directamente
afines con la relación propia que se ostenta con LA EMPRESA y solamente mientras esta dure, y no podrá ser usada
o destinada para propósito diferente.
LA EMPRESA también puede intercambiar Información Personal con las autoridades gubernamentales o públicas de
otro tipo (incluidas, entre otras autoridades judiciales o administrativas, autoridades fiscales y organismos de
investigación penal, civil, administrativa, disciplinaria o fiscal), y terceros participantes en procedimientos
legales civiles y sus contadores, auditores, abogados y otros asesores y representantes, porque es necesario o
apropiado en virtud de la ley, de requerimiento administrativo o judicial, o para el cumplimiento de las
presentes políticas de tratamiento de datos personales.


<h5>23. Función de protección de datos personales al interior de LA EMPRESA </h5>
LA EMPRESA designa al departamento técnico, o a la dependencia que haga sus veces, como el responsable que
recibirá, procesará y canalizará las distintas solicitudes que se reciban, y las hará llegar a la respectiva
dependencia ya mencionada encargada del tratamiento, dependencias que una vez reciban estas comunicaciones,
entrarán a cumplir con la función de protección de datos personales, y deberán dar trámite a las solicitudes de
los titulares, en los términos, plazos y condiciones establecidos por la normatividad vigente, para el ejercicio
de los derechos de acceso, consulta, rectificación, actualización, supresión y revocatoria a que se refiere la
normatividad vigente sobre la protección de datos personales.

En el evento en que usted considere que LA EMPRESA de un uso contrario al autorizado y a las leyes aplicables, o
requiera alguna solicitud, podrá contactarnos a través de una comunicación motivada y dirigida a la dirección:
Carrera 22 No. 166-78 de la ciudad de Bogotá. Correo electrónico: <a href="mailto:habeasdata@grupoadmark.com">habeasdata@grupoadmark.com</a>

<h5>24. Sistema De Videovigilancia</h5>
Los sistemas de video vigilancia implican la recopilación de imágenes de personas, es decir, de datos personales
(sensibles) de acuerdo con la redefinición contenida en la Ley 1581 de 2012, y en consecuencia el manejo o
Tratamiento de datos personales deben ser observados bajo los principios de legalidad, finalidad, libertad,
calidad, veracidad, seguridad, confidencialidad, acceso, circulación restringida y transparencia, contenidos en
el Régimen de Protección de Datos Personales en Colombia.
Por esta razón, esta política permite instrumentar los procedimientos de recolección y tratamiento de datos
personales para efectos de garantizar el control, parametrización y trazabilidad de los sistemas de monitoreo
por video vigilancia. LA EMPRESA pretende generar un esquema organizado para salvaguardar los datos privados,
semi privados, públicos y sensibles de sus titulares.
Los datos tratados mediante sistemas de video vigilancia serán preservados cumpliendo todas las disposiciones
legales que garanticen la privacidad de estos. En este sentido, el suministro de éstos podrá estar restringido o
limitado para efectos de resguardar la privacidad o por motivos de seguridad.

<b>Finalidad</b>
Las finalidades específicas para el tratamiento de datos recolectados mediante sistemas de video vigilancia
serán las siguientes:

Recopilación de imágenes de video de los visitantes y empleados.
Contar con medidas de seguridad para el monitoreo de incidentes.
Disuadir conductas irregulares de terceros.
Controlar el ingreso de usuarios, visitantes y empleados a las instalaciones de LA EMPRESA.
Como elemento material probatorio, con fines disciplinarios para los trabajadores.

Cada cámara de seguridad que se encuentre instalada en LA EMPRESA cuenta con un aviso de privacidad, el cual
informa a todos los usuarios, visitantes y empleados que se encuentra grabando y monitoreando para fines de
seguridad y los contenidos en la presente Política. Es por esta razón, que los titulares de la información dan
su autorización mediante conductas inequívocas, las cuales permiten concluir a los responsables que se otorgó la
autorización, pues se comunica previamente a las personas que van a ingresar a un establecimiento que sus
imágenes van a ser tomadas, conservadas o usadas de cierta manera y, conociendo tal situación, los titulares
ingresan al establecimiento.


<b>24.2 Aviso de Privacidad:</b> Se establecerá un aviso de privacidad en zonas cercanas a los lugares en que se realice el
monitoreo por video, el cual contará con información mínima sobre el tratamiento, destinaciones específicas y
demás información del interés del titular de los datos personales.

<h5>25. Tratamiento de datos biométricos con fines de control de acceso y seguridad </h5>
El tratamiento de datos sensibles incluye el reconocimiento de las huellas digitales. La ley establece que
ninguna actividad, servicio y/o similar, podrá estar condicionado a que el titular suministre datos personales
sensibles. Por lo anterior, contamos con todos los mecanismos para obtener la autorización del titular para el
tratamiento solicitado de acuerdo con lo requerido por la Ley y con las medidas de seguridad que procuran la
confidencialidad de los datos que conoceremos y/o recolectaremos.

<b>25.1. Finalidad</b>
Las finalidades específicas para el tratamiento de datos recolectados mediante sistemas biométricos a través de
la captura de la huella dactilar serán tratados con el único fin de llevar un control de acceso en las
instalaciones y permanencia de los trabajadores de LA EMPRESA.

<b>25.2 Vigencia</b>
El presente manual rige a partir del 1 de abril de 2021 y deja sin efectos los reglamentos o manuales especiales
que se hubiesen podido adoptar por instancias administrativas en LA EMPRESA