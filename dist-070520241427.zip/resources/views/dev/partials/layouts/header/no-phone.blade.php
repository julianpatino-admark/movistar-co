@php
    $query = "";

    if($tsource !== 0){
        $query = "?tsource=$tsource";
    }
@endphp
<header id="header" class="header_wrapper">
    <div class="container d-flex align-items-center justify-content-between">
        <div class="d-inline-flex align-items-center">
            <a href="{{URL('/').$query}}">
                <span class="header_logo d-none d-lg-block d-md-block">
                @include('dev.partials.components.icons.logo.brand-logo')
            </span>
                <span class="header_logo d-md-none d-lg-none d-sm-block">
                    @include('dev.partials.components.icons.logo.brand-logo-mobile')
                </span>
            </a>
        </div>
    </div>
</header>