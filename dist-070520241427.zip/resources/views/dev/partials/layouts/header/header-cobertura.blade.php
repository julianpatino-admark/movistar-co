<div class="header-cobertura">
    <div class="container">
        @include("dev.partials.components.icons.logo.brand-logo")
        <a href="/?{{request()->getQueryString()}}">&#60;Volver</a>
        <img class="digital-partner-image" height="70" width="126" src="{{ asset('/img/common/partner-aliado-movistar.svg') }}" alt="Etiqueta de aliado digital Movistar" />
    </div>
</div>