<section class="condition-collapse_wrapper" id="conditions">
	<div class="container">

		<div class="condition-collapse_header" id="headingOne">
			<h2 class="mb-0">
				<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne"
				        aria-expanded="true" aria-controls="collapseOne">
					Condiciones
				</button>
			</h2>
		</div>

		<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#conditions">
			<div class="condition-collapse_body">
				<p><a class="conditions_tyc_link" href="{{ secure_url('public/documents/tyc_online_febrero_1_2024.pdf') }}" target="_blank">Términos y Condiciones ofertas Hogar</a></p>

				<p><b>Términos y condiciones oferta pospago online</b><br>
					
					Terminos y Condiciones ofertas Hogar

					Oferta vigente del 1 al 15 de febrero 2024, válida exclusivamente para líneas portadas del segmento individual en el canal Online, no aplica en otros canales comerciales. El primer mes gratis + 50% de descuento en el mes 2 y 3 en el cargo básico aplica únicamente en planes pospago desde $44.990 mes hasta $65.990 mes. El descuento no aplica sobre contratación de servicios adicionales. El beneficio no podrá ser canjeable en dinero ni otros. Si el cliente entra en mora o es suspendido pierde los beneficios de descuento en el cargo fijo mensual. En caso de cambio de plan, el cliente pierde el beneficio del descuento.
				</p>
			</div>
		</div>
	</div>
</section>
