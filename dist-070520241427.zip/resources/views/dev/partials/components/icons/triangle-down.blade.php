<!-- Generator: Adobe Illustrator 23.0.1, SVG Export Plug-In  -->
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="16.3px"
     height="11px" viewBox="0 0 16.3 11" style="enable-background:new 0 0 16.3 11;" xml:space="preserve">
<style type="text/css">
    .btn-carousel_svg-fill{fill:#FF5800;}
</style>
    <defs>
    </defs>
    <polygon class="btn-carousel_svg-fill" points="8.15,11 16.3,0 0,0 "/>
</svg>
