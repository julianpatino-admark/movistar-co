<!-- Generator: Adobe Illustrator 23.0.1, SVG Export Plug-In  -->
<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="9.79px"
     height="22.05px" viewBox="0 0 9.79 22.05" style="enable-background:new 0 0 9.79 22.05;" xml:space="preserve">
<style type="text/css">
    .phone-lines-icon_path{fill:#FF5800;}
</style>
    <defs>
    </defs>
    <g>
        <path class="phone-lines-icon_path" d="M7.39,22.05H5.14c-3.07,0-5.14-2.59-5.14-5l0.01-11.7C0.01,2.77,2.02,0,5.02,0h2.25c2.4,0,2.4,2.24,2.4,3.58
		c0,1.07,0,3.58-2.05,3.58h-1.9c-0.3,0-0.52,0.12-0.65,0.33v6.61c0,0.39,0.2,0.8,0.77,0.8h1.9c2.05,0,2.05,2.51,2.05,3.58
		C9.79,19.81,9.79,22.05,7.39,22.05z M1.44,7.88v9.17c0,1.72,1.48,3.56,3.7,3.56h2.25c0.8,0,0.96-0.36,0.96-2.14
		c0-1.88-0.31-2.14-0.61-2.14h-1.9c-1.28,0-2.21-0.94-2.21-2.24l0.05-7.05C4.02,6.22,4.8,5.71,5.73,5.71h1.9
		c0.3,0,0.61-0.25,0.61-2.14c0-1.78-0.16-2.14-0.96-2.14H5.02c-2.11,0-3.57,2.06-3.57,3.91L1.44,7.88z"/>
    </g>
</svg>
