<!-- Generator: Adobe Illustrator 21.0.0, SVG Export Plug-In  -->
<svg version="1.1"
     xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:a="http://ns.adobe.com/AdobeSVGViewerExtensions/3.0/"
     x="0px" y="0px" width="22px" height="22px" viewBox="0 0 22 22" style="enable-background:new 0 0 22 22;" xml:space="preserve">
<style type="text/css">
    .icon-phone_path{fill:#FFFFFF;}
</style>
    <defs>
    </defs>
    <path class="icon-phone_path" d="M16.1,11.9l-3.5,3.5l-6-6l3.5-3.5L4.2,0L0.2,4.1L0,4.3v0.2C0,14.1,7.8,22,17.5,22h0.3l4.2-4.2L16.1,11.9z
	 M1.5,4.8L4.2,2l3.9,3.9L4.6,9.4l8,8l3.5-3.5l3.9,3.9l-2.8,2.8C8.6,20.4,1.6,13.4,1.5,4.8z"/>
</svg>
