<button class="hamburger collapsed" type="button" data-toggle="collapse" data-target="#navbarMobileCollapse" aria-controls="navbarMobileCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="hamburger-box">
          <span class="hamburger-inner"></span>
    </span>
</button>
