@php
    $showServices = isset($showServices) ? $showServices : true;
    $showContratacion = isset($showContratacion) ? $showContratacion : true;
    $keyword = (app('request')->get('keyword') !== null)?app('request')->get('keyword'):'';
    $keyword = (app('request')->get('mod') !== null)?app('request')->get('mod'):$keyword;
@endphp

<form id="{{ $id }}-form"
      method="post"
      data-toggle="form-simple"
      class="form @if(isset($class)){{$class}}@endif"
      data-layer-page="/c2c/principal/conversion"
      action="{{url('/api/form/send')}}">
    {{csrf_field()}}
    <input type="hidden" name="c2c" value="LLÁMAME GRATIS">
    <input type="hidden" name="id_version" value="{{$id_version}}">
    <input type="hidden" name="tsource" value="{{$tsource}}">
    <input type="hidden" name="batch_id" value="MOVISTARCO_KDMA_C2CLN_Q12">

    @if($showServices)
        @if ($showContratacion)
            <div>
                <label class="input-group-text statusLoader d-none"> <i class="select-loader"></i></label>
                <span id="selector-contratar-description" style="display: none;">Selector de servicios a contratar</span>
                <select
                    id="{{ $id }}-contratar"
                    name="contratar"
                    class="form-select"
                    aria-labelledby="selector-contratar-description"
                    required
                >
                    <option selected value="" hidden>* Contratar servicios</option>
                    <option value="si">Si</option>
                    <option value="no">No</option>
                </select>
            </div>
        @endif

        <label
            class="form-simple_title"
            for="{{ $id }}-selectServicios"
        >
            Escoge tus servicios
        </label>

        <div class="mb-2">
            <label class="input-group-text statusLoader d-none"> <i class="select-loader"></i></label>
            <select
                id="{{ $id }}-selectServicios"
                name="servicios"
                class="form-select"
                required
            >
                <option selected value="" hidden>Internet Hogar Fibra</option>
                <option value="internet">Internet Fibra</option>
                <option value="movil">Móvil</option>
            </select>
        </div>

        <p class="form-simple_description">
            ¡Déjanos tus datos y te ofrecemos el mejor precio!
        </p>

    @endif
    <div>
        <input
            type="text"
            name="phone"
            class="form-control"
            placeholder="* Número de Celular"
            data-rule-phone="col"
            data-test-id="input-c2c-phone"
            required
        >
    </div>

    @if($keyword == "cobertura")
        <div>
            <input type="text" name="direccion" class="form-control mb-0" placeholder="Dirección: Cll 103 # 13-30, Bogotá">
        </div>

        <div class="form-simple_addr">
            <input type="checkbox" name="specialaddr" id="checkSpecialAddr" data-toggle="toggle-enabled" data-elements="#{{ $id }}-inptDireccionAdicional">
            <label for="checkSpecialAddr">
                Mi dirección tiene especificaciones
            </label>
        </div>

        <div>
            <input type="text" class="form-control" id="{{ $id }}-inptDireccionAdicional" name="direccionAdicional" placeholder="Apto 502, torre 1, piso 3, etc" disabled  required>
        </div>
    @endif

    <div class="form-simple_tyc">
        <input type="checkbox" name="legal" id="legal" required>
        <label for="legal" class="text-xxs">
            Acepto
            <a
                href="#"
                data-toggle="modal"
                data-target="#modal-text"
                data-content="{{url('/privacy')}}"
                data-modal-title="Política de Privacidad"
                title="Política de privacidad"
            >
                política de privacidad
            </a>
            y tratamiento de
            <a
                href="#"
                data-toggle="modal"
                data-target="#modal-text"
                data-content="{{url('/privacy')}}"
                data-modal-title="Política de Privacidad"
                title="Política de privacidad"
            >
                datos personales y envío de mensajes vía WhatsApp.
            </a>
        </label>
        <label for="legal" class="error d-block"></label>
    </div>

    <div class="mb-2">
        <button
            id="btn-submit-{{ $id }}-form"
            class="form-control btn-form bg-degraded"
            data-c2c="TE LLAMAMOS"
        >
            <div class="btn-form_content font-family-bold">
                Llámame
            </div>
            <span class="btn-form_loader">
                <span class="loader"></span>
            </span>
        </button>
    </div>
</form>

