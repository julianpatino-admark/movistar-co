<div class="promo-cards poker">
    <div class="promo-cards_discount">
        <div class="promo-cards_speed">{{ $speed }}</div>
        <span class="promo-cards_undertext">{{ $promo }}</span>
    </div>
    <div class="separador"></div>
    <div class="promo-cards_price">${{ $price }}</div>
    <div class="promo-cards_offert">{{ $text }}</div>
</div>
